import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {

		// existe o sc.nextInt sc.nextDouble sc.next e next().charSt(0)
		Scanner sc = new Scanner(System.in);

		int x;
		x = sc.nextInt();

		System.out.println("Você digitou: " + x);

		sc.close();

	}

}
