
public class Main4 {

	public static void main(String[] args) {

		// teste de processamento de dados

		double b, B, h, area;

		b = 6.0;
		B = 8.0;
		h = 5.0;

		area = (b + B) / 2.0 * h;

		System.out.println(area);

	}

}
