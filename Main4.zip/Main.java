import java.util.Locale;

class Main {

	public static void main(String[] args) {
		
		double x = 10.35784;
		String nome = "Maria";
		int idade = 31;
		double renda = 4000.0;
				
// teste de formatação
		
		Locale.setDefault(Locale.US);
		System.out.printf("%.3f%n", x);
		System.out.println(x); 
		System.out.println("RESULTADO = " + x  + " METROS");
		System.out.printf("RESULTADO = %.1f metros%n", x);
		System.out.printf(nome + " TEM " + idade + " anos%n");
		System.out.printf("%s tem %d anos e ganha R$ %.2f reais%n", nome, idade, renda);
		
	}

}
