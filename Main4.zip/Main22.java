/*
public class Main22 {

	public static void main(String[] args) {

		double preco = 34.5;
		double desconto;
		if (preco < 20.0) {
			desconto = preco * 0.1;
		} else {
			desconto = preco * 0.05;
		}
		System.out.println(desconto);
	}

}
*/

//O MESMO CÓDIGO, PORÉM COM A EXPRESSÃO CONDIÇÃO TERNÁRIA

public class Main22 {

	public static void main(String[] args) {

		double preco = 34.5;
 		double desconto = (preco < 20.0) ? preco * 0.1 : preco * 0.05;
		System.out.println(desconto);
	}

}