import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {
	
		// PARA LER QUEBRA DE LINHA EM TEXTO sc.nextLine
		//ler vários dados na mesma linha
		//limpar o buffer de leitura é importante
		// setar o Locale.setDefault(Locale.US); caso queira fazer o input com "." ponto
		Scanner sc = new Scanner(System.in); 
		
		String x;
		int y;
		double z;
		
		x = sc.next();
		y = sc.nextInt();
		z = sc.nextDouble();
		
		System.out.println("Dados digitados: ");
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
						
		sc.close();		
		
		

	}

}
