import java.util.Scanner;

public class Main9 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a, b, soma;
		
		a = sc.nextInt();
		b = sc.nextInt();
		
		soma = a + b;
		
		System.out.println("A soma dos dois números é: ", soma);
		
		
		
		sc.close();
		
//soma de dois números inteiros

	}

}
