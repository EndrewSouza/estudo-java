import java.util.Scanner;

public class Main24 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int num = sc.nextInt();
		int senha = 2002;

		while (num != senha) {
			System.out.println("SENHA INVALIDA");
			num = sc.nextInt();

		}
		System.out.println("Acesso permitido");

		sc.close();
	}

}

//UM PROGRAMA QUE FAZ A LEITURA DE UMA SENHA ATÉ QUE ELA SEJA VÁLIDA
// CADA LEITURA INCORRETA, ELE PEDE PARA DIGITAR NOVAMENTE A "SENHA""
//"QUANDO" O USUÁRIO DIGITA O NÚMERO CORRETO, É MENSAGEM ACESSO PERMITIDO APARECE