/*import java.util.Scanner;

public class Main23 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int x = sc.nextInt();
		int soma = 0;
				
		while (x != 0) {
			
			x = sc.nextInt();
			soma = soma + x;
			
			System.out.println(soma);

		}

		sc.close();
	}

}
//teste uso while
// código faz a soma dos dígitos até o 0 ser digitado*/

/*import java.util.Scanner;

public class Main23 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int x = 5;
		int y = 0;
				
		while (x > 2 ) {
			System.out.println(y);
			y = y + x;
			x = x - 1;
		}

		sc.close();
	}

}*/





public class Main23 {

	public static void main(String[] args) {


		double x = 100.00;
		double y = 100.00;
				
		while (x != y ) {
			System.out.println("olha");
			x = Math.sqrt(y);
		}

		
	}
	
}	