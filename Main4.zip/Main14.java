import java.util.Scanner;
public class Main14 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in); 
		
		int numero;
		
		numero = sc.nextInt();
				
		if (numero < 0) {	
				System.out.println("Este número é NEGATIVO");
		}
		
		else {
			System.out.println("Este número não é negativo");
			
		}
		
		sc.close();
		
//Fazer um programa para ler um número inteiro, e depois dizer se este número é negativo ou não.
		
		
		
		
		
		

	}

}
