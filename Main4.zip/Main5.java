import java.util.Scanner;

public class Main5 {
	// teste de entrada de dados, é necessário utilizar o scanner para armazenar 
	// os dados preenchidos pelo usuário e o sc.next para receber 
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String x;
		x = sc.next();
		
		System.out.println("Você digitou: " + x);
						
		sc.close();		

	}

}
