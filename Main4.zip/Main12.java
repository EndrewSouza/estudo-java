import java.util.Scanner;
public class Main12 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in); 
		
		int num_funcionario, horastrab;
		float valor_hora, calc;
		
		
		num_funcionario = sc.nextInt();
		horastrab = sc.nextInt();
		valor_hora = sc.nextFloat();
		
		calc = horastrab * valor_hora;
		
		System.out.printf("NUMBER = %d%nSALARY = %.2f%n", num_funcionario, calc);
		
		
		
		
		sc.close();
		
		

	}

}
