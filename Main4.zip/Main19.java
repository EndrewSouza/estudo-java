import java.util.Locale;
import java.util.Scanner;

public class Main19 {

	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		
		//CALCULA A TAXA DE UMA FRANQUIA DE TELEFONIA, ONDE É COBRADO O VALOR DE R$2.00
		// A CADA MINUTO EXCEDENTE DO PLANO COM UMA FRANQUIA DE 100 MINUTOS

		int minutos;
		double valor_plano;

		minutos = sc.nextInt();
		valor_plano = 50.00;

		if (minutos > 100) {
			valor_plano = valor_plano + (minutos - 100) * 2.0;
			System.out.printf("O valor do plano é: R$ %.2f%n", valor_plano);
		}

		sc.close();
	}

}
