
public class Main3 {

	public static void main(String[] args) {
		// teste de processamento de dados
		
		int x, y;
		
		x = 5;
		
		y = 2 * x;
		
		System.out.println(x);
		System.out.println(y);

	}

}
